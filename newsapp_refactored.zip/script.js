const apiKey = "PUT_YOUR_API_KEY_HERE";
const newsContainer = document.getElementById("newsContainer");
const searchInput = document.getElementById("searchInput");
const categorySelect = document.getElementById("categorySelect");
const darkModeToggle = document.getElementById("darkModeToggle");

async function fetchNews(query = "", category = "general") {
    const url = `https://newsapi.org/v2/top-headlines?country=us&category=${category}&q=${query}&apiKey=${apiKey}`;
    try {
        const res = await fetch(url);
        const data = await res.json();
        renderNews(data.articles);
    } catch (err) {
        newsContainer.innerHTML = "<p>Failed to load news. Check API key.</p>";
    }
}

function renderNews(articles) {
    newsContainer.innerHTML = "";
    if (!articles || articles.length === 0) {
        newsContainer.innerHTML = "<p>No news found!</p>";
        return;
    }
    articles.forEach(article => {
        const card = document.createElement("div");
        card.classList.add("card");
        card.innerHTML = `
            <img src="${article.urlToImage || "assets/placeholder.jpg"}" alt="news image">
            <h3>${article.title}</h3>
            <p>${article.description || ""}</p>
            <a href="${article.url}" target="_blank">Read more</a>
        `;
        newsContainer.appendChild(card);
    });
}

// Event Listeners
searchInput.addEventListener("input", () => {
    fetchNews(searchInput.value, categorySelect.value);
});
categorySelect.addEventListener("change", () => {
    fetchNews(searchInput.value, categorySelect.value);
});
darkModeToggle.addEventListener("click", () => {
    document.body.classList.toggle("dark-mode");
});

// Initial load
fetchNews();
